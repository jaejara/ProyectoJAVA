/**
 * Clase BicicletaElectrica
 * ------------------------
 * Especializa el comportamiento de Bicicleta agregando autonomía en
 * kilómetros, certificación de la batería y la posibilidad de participar en
 * el programa de garantía extendida del taller (implementa la interfaz
 * ConGarantiaExtendida).
 */
public class BicicletaElectrica extends Bicicleta implements ConGarantiaExtendida {

    private static final double COSTO_BASE = 45000;
    private static final double RECARGO_BATERIA_NO_CERTIFICADA = 0.25;

    private double autonomiaKm;
    private boolean bateriaCertificada;
    private boolean garantiaExtendidaActiva;

    /**
     * El constructor delega en los setters, incluyendo los heredados de
     * Bicicleta, para que todas las validaciones se apliquen desde la
     * creación del objeto. La garantía extendida siempre nace desactivada;
     * se activa explícitamente mediante activarGarantiaExtendida().
     */
    public BicicletaElectrica(String codigo, int anioFabricacion, double peso,
                               double autonomiaKm, boolean bateriaCertificada) {
        super(codigo, anioFabricacion, peso);
        setAutonomiaKm(autonomiaKm);
        setBateriaCertificada(bateriaCertificada);
        this.garantiaExtendidaActiva = false;
    }

    // ------------------------- Getters / Setters -------------------------

    public double getAutonomiaKm() {
        return autonomiaKm;
    }

    public void setAutonomiaKm(double autonomiaKm) {
        if (autonomiaKm <= 0) {
            throw new IllegalArgumentException("La autonomía debe ser un valor mayor que cero.");
        }
        this.autonomiaKm = autonomiaKm;
    }

    public boolean isBateriaCertificada() {
        return bateriaCertificada;
    }

    public void setBateriaCertificada(boolean bateriaCertificada) {
        this.bateriaCertificada = bateriaCertificada;
    }

    public boolean isGarantiaExtendidaActiva() {
        return garantiaExtendidaActiva;
    }

    public void setGarantiaExtendidaActiva(boolean garantiaExtendidaActiva) {
        this.garantiaExtendidaActiva = garantiaExtendidaActiva;
    }

    // -------------------- Implementación ConGarantiaExtendida --------------------

    @Override
    public boolean tieneGarantiaExtendida() {
        return garantiaExtendidaActiva;
    }

    @Override
    public void activarGarantiaExtendida() {
        this.garantiaExtendidaActiva = true;
    }

    // -------------------- Especialización de Bicicleta --------------------

    /**
     * Costo base $45.000. Si la batería no está certificada, el costo se
     * incrementa en un 25%.
     */
    @Override
    public double calcularCostoMantencion() {
        double costo = COSTO_BASE;
        if (!bateriaCertificada) {
            costo += costo * RECARGO_BATERIA_NO_CERTIFICADA;
        }
        return costo;
    }

    @Override
    public String getTipo() {
        return "Bicicleta Eléctrica";
    }

    @Override
    public String getDetalleEspecifico() {
        // Si la autonomía es un número entero (60.0) se muestra como "60"
        String autonomiaTexto = (autonomiaKm == Math.floor(autonomiaKm))
                ? String.valueOf((int) autonomiaKm)
                : String.valueOf(autonomiaKm);
        return "Autonomia: " + autonomiaTexto + " km | Batería certificada: " + (bateriaCertificada ? "Si" : "No")
                + " | Garantia extendida: " + (garantiaExtendidaActiva ? "Si" : "No");
    }
}
