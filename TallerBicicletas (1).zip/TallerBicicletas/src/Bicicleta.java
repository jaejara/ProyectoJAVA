/**
 * Clase abstracta Bicicleta
 * -------------------------
 * Representa el comportamiento y los atributos comunes a todas las
 * bicicletas administradas por el taller: código, año de fabricación y
 * peso. El costo de mantención se calcula de manera distinta según el tipo
 * concreto de bicicleta, por lo que se declara como método abstracto:
 * esto obliga a cada subclase (BicicletaElectrica, BicicletaMontanya) a
 * entregar su propia implementación, permitiendo que el gestor del taller
 * calcule el costo de cualquier bicicleta sin conocer su tipo específico
 * (polimorfismo).
 */
public abstract class Bicicleta {

    // ---- Atributos comunes (encapsulados con modificador "protected" para
    // que las subclases puedan acceder a ellos directamente si lo requieren,
    // aunque el acceso recomendado sigue siendo a través de getters/setters) ----
    protected String codigo;
    protected int anioFabricacion;
    protected double peso;

    /**
     * Constructor de la clase base. Delega la asignación de cada valor a su
     * respectivo método "set", de modo que las validaciones definidas se
     * apliquen también durante la construcción del objeto.
     */
    public Bicicleta(String codigo, int anioFabricacion, double peso) {
        setCodigo(codigo);
        setAnioFabricacion(anioFabricacion);
        setPeso(peso);
    }

    // ------------------------- Getters / Setters -------------------------

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        if (codigo == null || codigo.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de bicicleta no puede ser nulo ni vacío.");
        }
        this.codigo = codigo.trim();
    }

    public int getAnioFabricacion() {
        return anioFabricacion;
    }

    public void setAnioFabricacion(int anioFabricacion) {
        if (anioFabricacion < 2000 || anioFabricacion > 2026) {
            throw new IllegalArgumentException(
                    "El año de fabricación debe encontrarse en el rango entre 2000 y 2026.");
        }
        this.anioFabricacion = anioFabricacion;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        if (peso <= 0) {
            throw new IllegalArgumentException("El peso debe ser un valor mayor que cero.");
        }
        this.peso = peso;
    }

    // --------------------------- Métodos abstractos ---------------------------

    /**
     * Calcula el costo de mantención de la bicicleta. Cada subclase concreta
     * define su propia lógica de cálculo (polimorfismo de sobrescritura).
     *
     * @return costo de mantención en pesos chilenos.
     */
    public abstract double calcularCostoMantencion();

    /**
     * Entrega el nombre descriptivo del tipo de bicicleta
     * (ej. "Bicicleta Eléctrica", "Bicicleta de Montaña").
     */
    public abstract String getTipo();

    /**
     * Entrega, en formato de texto, los atributos propios del tipo concreto
     * de bicicleta (autonomía, suspensiones, etc.). Se utiliza para mostrar
     * el detalle completo de una bicicleta sin necesidad de preguntar por su
     * tipo concreto (evita el uso de instanceof / verificaciones de tipo).
     */
    public abstract String getDetalleEspecifico();

    // ------------------------------- toString -------------------------------

    /**
     * Representación textual mínima de la bicicleta: únicamente su código y
     * año de fabricación, tal como lo solicita el enunciado. Este método se
     * utiliza de forma polimórfica al listar todas las bicicletas del taller.
     */
    @Override
    public String toString() {
        return "Código: " + codigo + " | Año: " + anioFabricacion;
    }
}
