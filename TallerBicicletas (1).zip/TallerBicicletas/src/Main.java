import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Scanner;

/*
 * ============================================================================
 *  IL 1.1 — Paradigma Orientado a Objetos vs. Paradigma Procedural/Estructurado
 * ============================================================================
 * Este programa está escrito en Java, un lenguaje que implementa el paradigma
 * orientado a objetos (POO). A continuación se documentan, mediante
 * comentarios, al menos dos diferencias respecto de un paradigma procedural
 * (por ejemplo, C o Pascal):
 *
 * 1) TIPADO:
 *    Java es un lenguaje de TIPADO ESTÁTICO Y FUERTE: el tipo de cada
 *    variable (String, int, double, boolean, Bicicleta, etc.) se declara y
 *    se verifica en tiempo de COMPILACIÓN. En cambio, en muchos lenguajes de
 *    paradigma procedural con tipado dinámico (por ejemplo, Python clásico o
 *    JavaScript) el tipo de una variable se determina recién en tiempo de
 *    EJECUCIÓN, pudiendo incluso cambiar durante el ciclo de vida del
 *    programa.
 *    Argumento (IL 1.1.2): el tipado estático de Java permite detectar
 *    tempranamente errores de programación —como intentar sumar un String
 *    con un objeto Bicicleta, o pasar un tipo de dato incorrecto como
 *    argumento a un método— directamente en la fase de compilación, antes de
 *    que el programa llegue a ejecutarse. Esto reduce la cantidad de errores
 *    que solo se manifestarían en tiempo de ejecución (por ejemplo, un
 *    ClassCastException o un comportamiento inesperado), aumentando la
 *    confiabilidad del software y facilitando su mantención.
 *
 * 2) DECLARACIÓN DE VARIABLES:
 *    En Java (POO, tipado estático) toda variable debe DECLARARSE de forma
 *    explícita indicando su tipo antes de usarla, por ejemplo:
 *    "int anioFabricacion = 2023;" o "String codigo = "BIC-E01";". Además,
 *    los atributos se declaran dentro de una CLASE con un modificador de
 *    acceso (private/protected) y se manipulan mediante métodos de esa misma
 *    clase (encapsulamiento). En cambio, en un lenguaje procedural con
 *    tipado dinámico se puede escribir simplemente "anio = 2023" sin
 *    declarar el tipo, y los datos suelen vivir en variables sueltas
 *    (globales) que las funciones modifican, sin quedar protegidos dentro
 *    de un objeto.
 *
 * 3) CICLO DE EJECUCIÓN / COMPILACIÓN:
 *    Java sigue un ciclo híbrido: el código fuente (.java) se COMPILA a
 *    bytecode (.class), y luego ese bytecode es INTERPRETADO (y
 *    parcialmente compilado "just-in-time") por la Máquina Virtual de Java
 *    (JVM). Esto se diferencia de lenguajes puramente compilados a código
 *    máquina nativo (como C), donde no existe una máquina virtual
 *    intermedia, y de lenguajes puramente interpretados (como versiones
 *    clásicas de Python), donde no hay una fase de compilación previa que
 *    genere un artefacto binario intermedio verificable.
 * ============================================================================
 */

/**
 * Clase principal del sistema de administración del taller de bicicletas.
 * Demuestra el funcionamiento completo del sistema: creación de objetos,
 * registro en el gestor, búsqueda por código y listado polimórfico.
 */
public class Main {

    public static void main(String[] args) {

        // Se fuerza la salida de consola a UTF-8 para que las tildes y la letra
        // "ñ" se muestren correctamente sin importar la configuración regional
        // del computador donde se ejecute el programa (BlueJ / IntelliJ / consola).
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));

        GestorTallerBicicletas gestor = new GestorTallerBicicletas();

        // --------------------------------------------------------------
        // 1) Instanciar una bicicleta de cada tipo disponible, delegando
        //    las validaciones a los constructores/setters. Se envuelve la
        //    creación en try-catch para que un dato inválido nunca detenga
        //    la ejecución del programa (IL 1.5): en su lugar, se informa el
        //    problema por consola.
        // --------------------------------------------------------------
        BicicletaElectrica electrica1 = null;
        try {
            electrica1 = new BicicletaElectrica("BIC-E01", 2023, 22.5, 60, false);
        } catch (IllegalArgumentException e) {
            System.out.println("No fue posible crear la bicicleta BIC-E01: " + e.getMessage());
        }

        BicicletaElectrica electrica2 = null;
        try {
            electrica2 = new BicicletaElectrica("BIC-E02", 2022, 24.0, 45, true);
        } catch (IllegalArgumentException e) {
            System.out.println("No fue posible crear la bicicleta BIC-E02: " + e.getMessage());
        }

        BicicletaMontanya montanya1 = null;
        try {
            montanya1 = new BicicletaMontanya("BIC-M01", 2021, 13.5, 2);
        } catch (IllegalArgumentException e) {
            System.out.println("No fue posible crear la bicicleta BIC-M01: " + e.getMessage());
        }

        BicicletaMontanya montanya2 = null;
        try {
            montanya2 = new BicicletaMontanya("BIC-M02", 2020, 12.0, 1);
        } catch (IllegalArgumentException e) {
            System.out.println("No fue posible crear la bicicleta BIC-M02: " + e.getMessage());
        }

        // --------------------------------------------------------------
        // 2) Marcar la Bicicleta Eléctrica "BIC-E01" con garantía extendida
        //    una vez creada.
        // --------------------------------------------------------------
        if (electrica1 != null) {
            electrica1.activarGarantiaExtendida();
        }

        // --------------------------------------------------------------
        // 3) Registrar todas las bicicletas en el gestor del sistema.
        // --------------------------------------------------------------
        if (electrica1 != null) gestor.registrarBicicleta(electrica1);
        if (electrica2 != null) gestor.registrarBicicleta(electrica2);
        if (montanya1 != null) gestor.registrarBicicleta(montanya1);
        if (montanya2 != null) gestor.registrarBicicleta(montanya2);

        // --------------------------------------------------------------
        // 4) Solicitar al usuario el código a buscar, validando la entrada
        //    y sin interrumpir el programa ante datos inválidos
        //    (IE 1.5.2, IE 1.5.3, IE 1.5.4).
        // --------------------------------------------------------------
        Scanner scanner = new Scanner(System.in);
        String criterioBusqueda = null;
        boolean entradaValida = false;

        while (!entradaValida) {
            try {
                System.out.print("\nIngrese el código de bicicleta a buscar (ej: BIC-E01): ");
                String entrada = scanner.nextLine();
                criterioBusqueda = validarCriterioBusqueda(entrada);
                entradaValida = true;
            } catch (IllegalArgumentException e) {
                System.out.println("Entrada inválida: " + e.getMessage() + " Intente nuevamente.");
            }
        }

        // --------------------------------------------------------------
        // 5) Buscar por código y mostrar el resultado.
        // --------------------------------------------------------------
        System.out.println("\n=== BUSQUEDA POR CODIGO: \"" + criterioBusqueda + "\" ===");
        List<Bicicleta> encontradas = gestor.buscarPorCodigo(criterioBusqueda, true);

        if (encontradas.isEmpty()) {
            System.out.println("No se encontraron bicicletas con el código \"" + criterioBusqueda + "\".");
        } else {
            for (Bicicleta bicicleta : encontradas) {
                mostrarDetalle(bicicleta);
            }
        }
        System.out.println("---");

        // --------------------------------------------------------------
        // 6) Listar todas las bicicletas registradas mediante toString().
        //    El recorrido es POLIMÓRFICO: se invoca toString() a través de
        //    la referencia Bicicleta, sin verificar el tipo concreto de
        //    cada objeto (IE 1.5.1, IE 1.6.2).
        // --------------------------------------------------------------
        System.out.println("\n=== LISTADO DE BICICLETAS ===");
        for (Bicicleta bicicleta : gestor.obtenerBicicletas()) {
            System.out.println(bicicleta.toString());
        }

        scanner.close();
    }

    /**
     * Sobrecarga de método (IE 1.2.3): versión con un solo parámetro que
     * muestra el detalle de una bicicleta usando un formato por defecto.
     */
    private static void mostrarDetalle(Bicicleta bicicleta) {
        mostrarDetalle(bicicleta, "$");
    }

    /**
     * Sobrecarga de método (IE 1.2.3): variante que además recibe el
     * símbolo de moneda a utilizar al mostrar el costo de mantención.
     * Ambas versiones comparten el nombre "mostrarDetalle" pero se
     * diferencian en la cantidad de parámetros recibidos.
     *
     * El detalle se arma exclusivamente a través de métodos de la clase
     * base (getTipo, getDetalleEspecifico, calcularCostoMantencion), por lo
     * que el comportamiento es polimórfico: no se pregunta en ningún
     * momento por el tipo concreto del objeto.
     */
    private static void mostrarDetalle(Bicicleta bicicleta, String simboloMoneda) {
        System.out.println(
                "Tipo: " + bicicleta.getTipo()
                        + " | Código: " + bicicleta.getCodigo()
                        + " | Año: " + bicicleta.getAnioFabricacion()
                        + " | Peso: " + bicicleta.getPeso() + " kg"
                        + " | " + bicicleta.getDetalleEspecifico()
                        + " | Costo mantención: " + simboloMoneda + (int) bicicleta.calcularCostoMantencion());
    }

    /**
     * Valida que el criterio de búsqueda ingresado por el usuario no sea
     * nulo ni esté vacío. Se utiliza IllegalArgumentException para
     * mantener consistencia con las validaciones del modelo de datos.
     */
    private static String validarCriterioBusqueda(String entrada) {
        if (entrada == null || entrada.trim().isEmpty()) {
            throw new IllegalArgumentException("El código de búsqueda no puede estar vacío.");
        }
        return entrada.trim();
    }
}
