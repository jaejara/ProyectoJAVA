/**
 * Interfaz ConGarantiaExtendida
 * ------------------------------
 * Define el contrato que deben cumplir las bicicletas que participan en el
 * programa de garantía extendida del taller. Al ser una interfaz (y no parte
 * de la jerarquía de herencia), cualquier tipo de bicicleta podrá adherirse
 * a este programa en el futuro sin necesidad de modificar la jerarquía de
 * clases existente (Bicicleta, BicicletaElectrica, BicicletaMontanya).
 *
 * Por ahora, solo BicicletaElectrica implementa este contrato.
 */
public interface ConGarantiaExtendida {

    /**
     * Permite consultar en cualquier momento si la bicicleta tiene una
     * garantía extendida activa.
     *
     * @return true si la garantía extendida está activa, false en caso contrario.
     */
    boolean tieneGarantiaExtendida();

    /**
     * Permite activar la garantía extendida de la bicicleta.
     */
    void activarGarantiaExtendida();
}
