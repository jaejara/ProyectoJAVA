/**
 * Clase BicicletaMontanya
 * -----------------------
 * Especializa el comportamiento de Bicicleta agregando la cantidad de
 * suspensiones, atributo que incide directamente en el costo de mantención.
 */
public class BicicletaMontanya extends Bicicleta {

    private static final double COSTO_BASE = 30000;
    private static final double RECARGO_MAS_DE_UNA_SUSPENSION = 0.15;

    private int cantidadSuspensiones;

    public BicicletaMontanya(String codigo, int anioFabricacion, double peso, int cantidadSuspensiones) {
        super(codigo, anioFabricacion, peso);
        setCantidadSuspensiones(cantidadSuspensiones);
    }

    // ------------------------- Getters / Setters -------------------------

    public int getCantidadSuspensiones() {
        return cantidadSuspensiones;
    }

    public void setCantidadSuspensiones(int cantidadSuspensiones) {
        if (cantidadSuspensiones < 0) {
            throw new IllegalArgumentException("La cantidad de suspensiones no puede ser negativa.");
        }
        this.cantidadSuspensiones = cantidadSuspensiones;
    }

    // -------------------- Especialización de Bicicleta --------------------

    /**
     * Costo base $30.000. Si la cantidad de suspensiones supera 1, el costo
     * se incrementa en un 15%.
     */
    @Override
    public double calcularCostoMantencion() {
        double costo = COSTO_BASE;
        if (cantidadSuspensiones > 1) {
            costo += costo * RECARGO_MAS_DE_UNA_SUSPENSION;
        }
        return costo;
    }

    @Override
    public String getTipo() {
        return "Bicicleta de Montaña";
    }

    @Override
    public String getDetalleEspecifico() {
        return "Suspensiones: " + cantidadSuspensiones;
    }
}
