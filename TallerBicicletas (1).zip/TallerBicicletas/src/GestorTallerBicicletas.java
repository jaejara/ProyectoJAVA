import java.util.ArrayList;
import java.util.List;

/**
 * Clase GestorTallerBicicletas
 * ----------------------------
 * Administra la colección de bicicletas registradas en el taller y expone
 * las operaciones sobre ella: registro y búsqueda por código.
 *
 * La colección se declara parametrizada con la clase base (List<Bicicleta>),
 * lo que permite almacenar de forma uniforme objetos de distintos subtipos
 * (BicicletaElectrica, BicicletaMontanya) y operar sobre ellos de manera
 * polimórfica, sin necesidad de conocer su tipo concreto.
 */
public class GestorTallerBicicletas {

    private List<Bicicleta> bicicletas;

    public GestorTallerBicicletas() {
        this.bicicletas = new ArrayList<>();
    }

    /**
     * Registra una bicicleta en la colección e informa por consola que fue
     * incorporada correctamente.
     */
    public void registrarBicicleta(Bicicleta bicicleta) {
        bicicletas.add(bicicleta);
        System.out.println(bicicleta.getCodigo() + " (" + bicicleta.getClass().getSimpleName()
                + ") registrada correctamente.");
    }

    /**
     * Sobrecarga 1: busca y retorna las bicicletas cuyo código coincida
     * (coincidencia parcial, sin distinguir mayúsculas/minúsculas) con el
     * criterio de búsqueda recibido.
     */
    public List<Bicicleta> buscarPorCodigo(String criterio) {
        return buscarPorCodigo(criterio, false);
    }

    /**
     * Sobrecarga 2: variante del mismo comportamiento que permite indicar si
     * la coincidencia debe ser exacta o parcial. Ambas versiones comparten el
     * mismo propósito (buscar bicicletas por código) pero se diferencian en
     * la cantidad de parámetros recibidos.
     */
    public List<Bicicleta> buscarPorCodigo(String criterio, boolean coincidenciaExacta) {
        List<Bicicleta> resultado = new ArrayList<>();
        if (criterio == null || criterio.trim().isEmpty()) {
            return resultado;
        }
        String criterioNormalizado = criterio.trim().toUpperCase();

        for (Bicicleta bicicleta : bicicletas) {
            String codigoActual = bicicleta.getCodigo().toUpperCase();
            boolean coincide = coincidenciaExacta
                    ? codigoActual.equals(criterioNormalizado)
                    : codigoActual.contains(criterioNormalizado);
            if (coincide) {
                resultado.add(bicicleta);
            }
        }
        return resultado;
    }

    /**
     * Retorna todas las bicicletas registradas en el taller.
     */
    public List<Bicicleta> obtenerBicicletas() {
        return bicicletas;
    }
}
